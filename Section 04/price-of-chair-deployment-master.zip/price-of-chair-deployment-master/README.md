# Pricing Service App - Deployment

Learn how to build Python apps with MongoDB!

This application is the final application of the Complete Python Web course. We will use it to learn about deployments in Ubuntu, using Python3.7, MongoDB, uWSGI, and nginx.

The guide is available in the course.
